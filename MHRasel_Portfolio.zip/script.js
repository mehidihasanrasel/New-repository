/* ══════════════════════════════════════════════════════════
   MHRasel Portfolio — script.js
   ✅ প্রতিটি function-এর উপরে বাংলায় comment দেওয়া আছে
   ✅ কোন code কী কাজ করে তা বোঝা যাবে
   ✅ সব feature একসাথে এই একটি ফাইলে
══════════════════════════════════════════════════════════ */


/* ══════════════════════════════════════════════════════════
   ১. PRELOADER — লোডিং স্ক্রিন
   কীভাবে কাজ করে:
   ক) প্রগ্রেস বার ০% থেকে ১০০% পর্যন্ত যায়
   খ) ১০০% হলে preReveal div দেখা যায় — ছবি পুরো স্ক্রিন ঢাকে
   গ) ১.৫ সেকেন্ড পর ছবি zoom-out হয়ে ছোট হতে থাকে
   ঘ) ৩ সেকেন্ড পর preloader মুছে যায়
══════════════════════════════════════════════════════════ */
(function runPreloader() {

  const fill   = document.getElementById('preFill');    /* প্রগ্রেস বারের fill */
  const pct    = document.getElementById('prePct');     /* % সংখ্যা */
  const reveal = document.getElementById('preReveal');  /* fullscreen ছবির div */
  const photo  = document.getElementById('prePhoto');   /* fullscreen ছবি */
  const loader = document.getElementById('preloader');  /* পুরো preloader */

  let progress = 0;

  /* প্রতি ৬০ms পর প্রগ্রেস বাড়ানো */
  const timer = setInterval(() => {
    progress += Math.random() * 8 + 2; /* এলোমেলো পরিমাণ — স্বাভাবিক দেখায় */

    if (progress >= 100) {
      progress = 100;
      clearInterval(timer);
      fill.style.width = '100%';
      pct.textContent  = '100%';

      /* ৩০০ms পর ছবি fullscreen দেখানো */
      setTimeout(() => {
        reveal.classList.add('show');

        /* ১.৫ সেকেন্ড পর ছবি ছোট হতে শুরু */
        setTimeout(startShrink, 1500);
      }, 300);
      return;
    }

    fill.style.width = progress + '%';
    pct.textContent  = Math.floor(progress) + '%';
  }, 60);


  /* ছবি ছোট হয়ে hero-র photo-box-এ চলে যাবে */
  function startShrink() {
    const box = document.getElementById('photoBox');

    if (box) {
      const rect  = box.getBoundingClientRect();
      /* স্ক্রিন থেকে photo-box-এর অনুপাত বের করা */
      const scale = Math.min(rect.width / window.innerWidth, rect.height / window.innerHeight);
      /* photo-box-এর কেন্দ্র বিন্দু */
      const tx    = (rect.left + rect.width / 2)  - window.innerWidth  / 2;
      const ty    = (rect.top  + rect.height / 2) - window.innerHeight / 2;

      /* CSS transition দিয়ে ধীরে ধীরে ছোট হবে */
      photo.style.transform    = `translate(${tx}px, ${ty}px) scale(${scale})`;
      photo.style.borderRadius = '26px';
    } else {
      photo.style.transform = 'scale(0)';
    }

    /* ৩ সেকেন্ড পর preloader সরানো */
    setTimeout(() => {
      loader.classList.add('done'); /* fade out */
      setTimeout(() => {
        loader.style.display = 'none';
        /* preloader শেষে সব জিনিস চালু */
        initAOS();
        heroReveal();
        initCounters();
        initSkillBars();
      }, 700);
    }, 3000);
  }

})();


/* ══════════════════════════════════════════════════════════
   ২. HERO REVEAL — preloader শেষে hero ছবি দেখানো
   কাজ: photo-box fade+scale করে দেখাবে
══════════════════════════════════════════════════════════ */
function heroReveal() {
  const box = document.getElementById('photoBox');
  if (!box) return;
  box.style.opacity    = '0';
  box.style.transform  = 'scale(0.85) translateY(20px)';
  box.style.transition = 'opacity .8s ease, transform .8s cubic-bezier(.34,1.56,.64,1)';
  setTimeout(() => {
    box.style.opacity   = '1';
    box.style.transform = 'scale(1) translateY(0)';
  }, 300);
}


/* ══════════════════════════════════════════════════════════
   ৩. CUSTOM CURSOR — কাস্টম মাউস কার্সার
   .cursor = বড় বৃত্ত, ধীরে আসে (smooth lerp)
   .cursor-dot = ছোট বিন্দু, সরাসরি মাউসে থাকে
══════════════════════════════════════════════════════════ */
(function initCursor() {
  const ring = document.getElementById('cursor');
  const dot  = document.getElementById('cursorDot');
  if (!ring || !dot) return;

  let mx=0, my=0, rx=0, ry=0;

  document.addEventListener('mousemove', e => {
    mx = e.clientX; my = e.clientY;
    /* dot সরাসরি মাউসে */
    dot.style.left = mx + 'px';
    dot.style.top  = my + 'px';
  });

  /* ring-কে lerp দিয়ে smooth করা */
  (function animRing() {
    rx += (mx - rx) * 0.12; /* ০.১২ = গতি */
    ry += (my - ry) * 0.12;
    ring.style.left = rx + 'px';
    ring.style.top  = ry + 'px';
    requestAnimationFrame(animRing);
  })();

  /* লিংকে hover করলে cursor বড় হয় */
  document.addEventListener('mouseover', e => {
    if (e.target.closest('a,button')) {
      ring.style.width = '48px'; ring.style.height = '48px';
      ring.style.borderColor = 'rgba(0,245,160,.8)';
    }
  });
  document.addEventListener('mouseout', e => {
    if (e.target.closest('a,button')) {
      ring.style.width = '32px'; ring.style.height = '32px';
      ring.style.borderColor = 'rgba(0,245,160,.5)';
    }
  });
})();


/* ══════════════════════════════════════════════════════════
   ৪. PARTICLE CANVAS — hero-র পার্টিকেল ব্যাকগ্রাউন্ড
   ছোট ছোট বিন্দু ভেসে বেড়ায়, কাছেরগুলো লাইনে যুক্ত
══════════════════════════════════════════════════════════ */
(function initParticles() {
  const canvas = document.getElementById('heroCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, particles = [];

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', () => { resize(); build(); });

  /* পার্টিকেল তৈরি */
  function build() {
    particles = [];
    const n = Math.min(55, Math.floor(W/22));
    for (let i=0; i<n; i++) particles.push({
      x: Math.random()*W, y: Math.random()*H,
      vx: (Math.random()-.5)*.4, vy: (Math.random()-.5)*.4,
      r: Math.random()*1.8+.5, a: Math.random()*.5+.2
    });
  }
  build();

  /* প্রতি frame-এ আঁকা */
  function draw() {
    ctx.clearRect(0,0,W,H);
    particles.forEach(p => {
      p.x+=p.vx; p.y+=p.vy;
      if(p.x<0||p.x>W) p.vx*=-1; /* প্রান্তে bounce */
      if(p.y<0||p.y>H) p.vy*=-1;
      ctx.beginPath();
      ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fillStyle = `rgba(0,245,160,${p.a*.55})`;
      ctx.fill();
    });
    /* কাছের পার্টিকেলে লাইন */
    for(let i=0;i<particles.length;i++)
      for(let j=i+1;j<particles.length;j++){
        const d = Math.hypot(particles[i].x-particles[j].x, particles[i].y-particles[j].y);
        if(d<110){
          ctx.beginPath();
          ctx.moveTo(particles[i].x,particles[i].y);
          ctx.lineTo(particles[j].x,particles[j].y);
          ctx.strokeStyle=`rgba(0,245,160,${(1-d/110)*.07})`;
          ctx.stroke();
        }
      }
    requestAnimationFrame(draw);
  }
  draw();
})();


/* ══════════════════════════════════════════════════════════
   ৫. TYPEWRITER — টাইপরাইটার অ্যানিমেশন
   পেশার নাম একটি একটি করে টাইপ হয়, তারপর মুছে পরেরটা
══════════════════════════════════════════════════════════ */
(function initTypewriter() {
  const el = document.getElementById('typed');
  if (!el) return;

  const texts = [
    'Excel Automation Expert',
    'Google Sheets Specialist',
    'Data Dashboard Designer',
    'Power Query & Analysis Expert',
    'Navana Pharma Data Lead'
  ];

  let ti=0, ci=0, del=false;

  function type() {
    const cur = texts[ti];
    if (!del) {
      el.textContent = cur.slice(0,++ci);
      if (ci===cur.length) { del=true; setTimeout(type,2000); return; }
      setTimeout(type, 80); /* টাইপ গতি */
    } else {
      el.textContent = cur.slice(0,--ci);
      if (ci===0) { del=false; ti=(ti+1)%texts.length; setTimeout(type,400); return; }
      setTimeout(type, 40); /* মোছার গতি */
    }
  }
  setTimeout(type, 200);
})();


/* ══════════════════════════════════════════════════════════
   ৬. NAVBAR — নেভিগেশন বার
   স্ক্রোলে blur, সক্রিয় লিংক highlight, মোবাইল মেনু
══════════════════════════════════════════════════════════ */
(function initNavbar() {
  const nav    = document.getElementById('navbar');
  const burger = document.getElementById('burger');
  const links  = document.querySelectorAll('.nl');

  window.addEventListener('scroll', () => {
    /* ৬০px স্ক্রোলে blur ব্যাকগ্রাউন্ড */
    nav.classList.toggle('stuck', window.scrollY > 60);
    /* উপরে যাওয়ার বাটন */
    document.getElementById('toTop').classList.toggle('show', window.scrollY > 400);
    /* সক্রিয় section খুঁজে লিংক highlight */
    let cur = '';
    document.querySelectorAll('section[id],div[id]').forEach(s => {
      if (window.scrollY >= s.offsetTop - 110) cur = s.id;
    });
    links.forEach(a => a.classList.toggle('on', a.getAttribute('href')==='#'+cur));
  }, { passive: true });

  /* মোবাইল মেনু toggle */
  burger.addEventListener('click', () => nav.classList.toggle('open'));
  links.forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
})();


/* ══════════════════════════════════════════════════════════
   ৭. THEME PICKER — থিম ও মোড পরিবর্তন
   🎨 বাটনে ক্লিক করলে প্যানেল খুলবে
   থিম সোয়াচে ক্লিক করলে accent রঙ পরিবর্তন হবে
══════════════════════════════════════════════════════════ */
(function initThemePicker() {
  const toggle  = document.getElementById('tpToggle');
  const box     = document.getElementById('tpBox');
  const swatches = document.querySelectorAll('.sw');

  /* প্যানেল খোলা/বন্ধ */
  toggle.addEventListener('click', e => { e.stopPropagation(); box.classList.toggle('open'); });
  document.addEventListener('click', () => box.classList.remove('open'));
  box.addEventListener('click', e => e.stopPropagation());

  /* থিম পরিবর্তন */
  swatches.forEach(sw => sw.addEventListener('click', () => {
    swatches.forEach(s => s.classList.remove('active'));
    sw.classList.add('active');
    document.body.setAttribute('data-t', sw.dataset.t);
  }));

  /* ডার্ক/লাইট মোড */
  document.getElementById('mbDark').addEventListener('click', () => {
    document.body.classList.remove('light');
    document.getElementById('mbDark').classList.add('active');
    document.getElementById('mbLight').classList.remove('active');
  });
  document.getElementById('mbLight').addEventListener('click', () => {
    document.body.classList.add('light');
    document.getElementById('mbLight').classList.add('active');
    document.getElementById('mbDark').classList.remove('active');
  });
})();


/* ══════════════════════════════════════════════════════════
   ৮. AOS — Animate On Scroll
   [data-aos] element viewport-এ এলে .vis class পাবে
   CSS-এ .vis দিয়ে fade+slide animate করা
══════════════════════════════════════════════════════════ */
function initAOS() {
  const els = document.querySelectorAll('[data-aos]');
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el    = e.target;
      const delay = el.dataset.delay || '0';
      el.style.transitionDelay = delay + 'ms';
      el.classList.add('vis');
      obs.unobserve(el); /* একবারই */
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
  els.forEach(el => obs.observe(el));
}


/* ══════════════════════════════════════════════════════════
   ৯. SECTION SCROLL REVEAL — section hide/show effect
   স্ক্রোলে আগের section উপরে clip হয়ে যায়
   নতুন section নিচে থেকে উঠে আসে — cinematic feel
══════════════════════════════════════════════════════════ */
(function initSectionReveal() {
  const sections = document.querySelectorAll('.sec');
  if (!sections.length) return;

  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      const sec = e.target;
      if (e.isIntersecting) {
        /* viewport-এ এলে: স্বাভাবিক অবস্থায় */
        sec.style.transform = 'translateY(0)';
        sec.style.opacity   = '1';
      } else {
        /* উপরে চলে গেলে: সামান্য উপরে shift */
        if (sec.getBoundingClientRect().top < 0) {
          sec.style.transform = 'translateY(-25px)';
          sec.style.opacity   = '0.7';
        }
      }
    });
  }, { threshold: [0, 0.1], rootMargin: '-5% 0px -5% 0px' });

  sections.forEach(sec => {
    sec.style.transition = 'transform .65s cubic-bezier(.4,0,.2,1), opacity .65s ease';
    obs.observe(sec);
  });
})();


/* ══════════════════════════════════════════════════════════
   ১০. COUNTER — সংখ্যা গণনা অ্যানিমেশন
   0 থেকে target পর্যন্ত ধীরে ধীরে বাড়ে (০→১৬, ০→৮ ইত্যাদি)
══════════════════════════════════════════════════════════ */
function initCounters() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el     = e.target;
      const target = parseInt(el.dataset.to);
      let   cur    = 0;
      const step   = target / 60;
      const t = setInterval(() => {
        cur = Math.min(cur + step, target);
        el.textContent = Math.floor(cur);
        if (cur >= target) clearInterval(t);
      }, 18);
      obs.unobserve(el);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll('.cnt').forEach(el => obs.observe(el));
}


/* ══════════════════════════════════════════════════════════
   ১১. SKILL BARS — দক্ষতার বার অ্যানিমেশন
   দেখা গেলে .go class যোগ হয় → CSS তখন width animate করে
══════════════════════════════════════════════════════════ */
function initSkillBars() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      e.target.classList.add('go');
      obs.unobserve(e.target);
    });
  }, { threshold: 0.3 });
  document.querySelectorAll('.sk-fill').forEach(b => obs.observe(b));
}


/* ══════════════════════════════════════════════════════════
   ১২. PROJECT FILTER — All/Dashboard/Automation/Analysis
   ফিল্টার বাটনে ক্লিক করলে সেই category-র কার্ড দেখাবে
══════════════════════════════════════════════════════════ */
(function initFilter() {
  const btns  = document.querySelectorAll('.pf');
  const cards = document.querySelectorAll('.pg-card');
  btns.forEach(btn => btn.addEventListener('click', () => {
    btns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const f = btn.dataset.f;
    cards.forEach(c => {
      if (f==='all' || c.dataset.cat===f) {
        c.style.display = '';
        c.style.animation = 'barUp .4s ease both';
      } else {
        c.style.display = 'none';
      }
    });
  }));
})();


/* ══════════════════════════════════════════════════════════
   ১৩. TESTIMONIAL SLIDER — রিভিউ স্লাইডার
   ← → বাটন, ডট নেভিগেশন, ৪ সেকেন্ড পর পর auto-play
══════════════════════════════════════════════════════════ */
(function initSlider() {
  const track = document.getElementById('tsTrack');
  const dotsW = document.getElementById('tsDots');
  const cards = document.querySelectorAll('.ts-card');
  if (!track || !cards.length) return;

  let cur = 0;
  const vis = () => window.innerWidth < 768 ? 1 : window.innerWidth < 1100 ? 2 : 3;

  /* ডট তৈরি */
  cards.forEach((_,i) => {
    const d = document.createElement('div');
    d.className = 'ts-dot' + (i===0?' on':'');
    d.addEventListener('click', () => go(i));
    dotsW.appendChild(d);
  });

  function go(idx) {
    const max = cards.length - vis();
    cur = Math.max(0, Math.min(idx, max));
    track.style.transform = `translateX(-${cur * (cards[0].offsetWidth + 22)}px)`;
    document.querySelectorAll('.ts-dot').forEach((d,i) => d.classList.toggle('on', i===cur));
  }

  document.getElementById('tsPrev').addEventListener('click', () => go(cur-1));
  document.getElementById('tsNext').addEventListener('click', () => go(cur+1>cards.length-vis()?0:cur+1));

  /* Auto slide */
  let auto = setInterval(() => go(cur+1>cards.length-vis()?0:cur+1), 4000);
  track.parentElement.addEventListener('mouseenter', () => clearInterval(auto));
  track.parentElement.addEventListener('mouseleave', () => {
    auto = setInterval(() => go(cur+1>cards.length-vis()?0:cur+1), 4000);
  });
})();


/* ══════════════════════════════════════════════════════════
   ১৪. CALENDAR — বুকিং ক্যালেন্ডার
   Available/Booked/Today আলাদা রঙ, তারিখ সিলেক্ট করা যায়
══════════════════════════════════════════════════════════ */
(function initCalendar() {
  const body = document.getElementById('calBody');
  const my   = document.getElementById('calMY');
  const sel  = document.getElementById('calSel');
  const prev = document.getElementById('calPrev');
  const next = document.getElementById('calNext');
  if (!body) return;

  /* Booked তারিখ (demo) */
  const booked = [2,7,11,14,19,23,28];
  const months = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December'];
  const now = new Date();
  let cm = now.getMonth(), cy = now.getFullYear();

  function render() {
    body.innerHTML = '';
    my.textContent = `${months[cm]} ${cy}`;
    const today    = new Date();
    const first    = new Date(cy,cm,1).getDay(); /* প্রথম দিন কোন বার */
    const total    = new Date(cy,cm+1,0).getDate(); /* মাসে কতদিন */

    /* প্রথম দিনের আগে খালি ঘর */
    for(let i=0;i<first;i++){
      const e=document.createElement('div'); e.className='cd'; body.appendChild(e);
    }

    for(let d=1;d<=total;d++){
      const cell = document.createElement('div');
      cell.className='cd'; cell.textContent=d;
      const dt     = new Date(cy,cm,d);
      const isToday= d===today.getDate() && cm===today.getMonth() && cy===today.getFullYear();
      const isPast = dt < new Date(today.getFullYear(),today.getMonth(),today.getDate());
      const isWknd = [0,6].includes(dt.getDay());

      if(isToday)            cell.classList.add('tdy');
      else if(isPast)        cell.classList.add('past');
      else if(booked.includes(d)||isWknd) cell.classList.add('bkd');
      else {
        cell.classList.add('avl');
        cell.addEventListener('click', () => {
          document.querySelectorAll('.cd.sel').forEach(c=>c.classList.remove('sel'));
          cell.classList.add('sel');
          sel.innerHTML = `<span>✅</span><span style="color:var(--acc)">${months[cm]} ${d}, ${cy} — <a href="#contact" style="color:var(--acc2)">Book Now</a></span>`;
        });
      }
      body.appendChild(cell);
    }
  }

  prev.addEventListener('click', () => { cm--; if(cm<0){cm=11;cy--;} render(); });
  next.addEventListener('click', () => { cm++; if(cm>11){cm=0;cy++;} render(); });
  render();
})();


/* ══════════════════════════════════════════════════════════
   ১৫. CONTACT FORM — যোগাযোগ ফর্ম validation ও submit
══════════════════════════════════════════════════════════ */
(function initForm() {
  const btn = document.getElementById('sendBtn');
  if (!btn) return;
  btn.addEventListener('click', () => {
    const n = document.getElementById('fn').value.trim();
    const e = document.getElementById('fe').value.trim();
    const m = document.getElementById('fm').value.trim();
    const ok= document.getElementById('ctOk');

    if(!n||!e||!m){ alert('❗ নাম, ইমেইল ও মেসেজ দিন।'); return; }
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)){ alert('❗ সঠিক ইমেইল দিন।'); return; }

    btn.textContent = '⏳ Sending...'; btn.disabled = true;
    setTimeout(() => {
      btn.innerHTML = '✅ Sent!';
      ok.style.display = 'block';
      ['fn','fe','fs','fm'].forEach(id => document.getElementById(id).value='');
      setTimeout(() => {
        btn.innerHTML = 'Send Message <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>';
        btn.disabled = false; ok.style.display='none';
      }, 4000);
    }, 1200);
  });
})();


/* ══════════════════════════════════════════════════════════
   ১৬. LO-FI MUSIC PLAYER — সঙ্গীত চালু/বন্ধ
   Browser autoplay policy: প্রথমবার user click লাগবে
   তারপর অডিও চলবে
══════════════════════════════════════════════════════════ */
(function initMusic() {
  const btn   = document.getElementById('mpBtn');
  const lbl   = document.getElementById('mpLbl');
  const wrap  = document.getElementById('mpl');
  const audio = document.getElementById('bgAudio');
  if (!btn || !audio) return;

  let playing = false;

  btn.addEventListener('click', async () => {
    if (!playing) {
      try {
        audio.volume = 0.15; /* ভলিউম ১৫% */
        await audio.play();
        playing = true;
        wrap.classList.remove('off'); /* বার অ্যানিমেশন চালু */
        lbl.textContent = '♪ Playing...';
      } catch(err) {
        /* Browser autoplay block হলে */
        lbl.textContent = '🎵 Click again';
        console.warn('Audio blocked:', err);
      }
    } else {
      audio.pause();
      playing = false;
      wrap.classList.add('off'); /* বার থামবে */
      lbl.textContent = 'Lo-Fi Music';
    }
  });

  audio.addEventListener('error', () => { lbl.textContent = '🎵 No Audio'; });
})();


/* ══════════════════════════════════════════════════════════
   ১৭. CHATBOT — মিনি চ্যাটবট
   keyword matching দিয়ে প্রশ্নের উত্তর দেয়
══════════════════════════════════════════════════════════ */
(function initChatbot() {
  const toggle = document.getElementById('cbToggle');
  const box    = document.getElementById('cbBox');
  const close  = document.getElementById('cbClose');
  const input  = document.getElementById('cbInp');
  const send   = document.getElementById('cbSend');
  const msgs   = document.getElementById('cbMsgs');
  const quick  = document.getElementById('cbQuick');
  const badge  = document.getElementById('cbBadge');
  if (!toggle) return;

  /* প্রশ্ন-উত্তর ভাণ্ডার */
  const KB = {
    services: '📊 আমি provide করি: Advanced Excel dashboard, Power Query automation, Google Sheets solution, Salary & Attendance system, Sales report ইত্যাদি!',
    exp:      '💼 Mehidi-র ৮+ বছরের অভিজ্ঞতা Navana Pharmaceuticals PLC-এ। Excel automation, data analysis ও reporting-এ বিশেষজ্ঞ।',
    contact:  '📞 Phone: +8801944717795 | Email: imrasel51@gmail.com | WhatsApp: +880 1540-725111',
    price:    '💰 Project-এর জটিলতা অনুযায়ী দাম। Simple task $10 থেকে শুরু। Custom quote-এর জন্য contact করুন!',
    default:  '🤔 বুঝিনি। services, experience, contact বা price সম্পর্কে জিজ্ঞেস করুন!'
  };

  /* chatbot খোলা/বন্ধ */
  toggle.addEventListener('click', () => {
    box.classList.toggle('open');
    if (box.classList.contains('open')) { badge.style.display='none'; input.focus(); }
  });
  close.addEventListener('click', () => box.classList.remove('open'));

  /* Message যোগ করা */
  function addMsg(text, who) {
    const d = document.createElement('div');
    d.className = `cbm ${who}`;
    d.innerHTML = `<div class="cbb">${text}</div>`;
    msgs.appendChild(d);
    msgs.scrollTop = msgs.scrollHeight;
  }

  /* Typing indicator */
  function showTyping() {
    const d = document.createElement('div');
    d.className='cbm bot typing'; d.innerHTML='<div class="cbb">...</div>';
    msgs.appendChild(d); msgs.scrollTop = msgs.scrollHeight;
  }
  function removeTyping() {
    const t = msgs.querySelector('.typing'); if(t) t.remove();
  }

  /* Bot reply — keyword matching */
  function botReply(text) {
    const t = text.toLowerCase();
    let reply = KB.default;
    if(t.match(/hello|hi|হ্যালো|হাই/))         reply = '👋 হ্যালো! আমি Rasel Bot। কী জানতে চান?';
    else if(t.match(/service|skill|কাজ/))       reply = KB.services;
    else if(t.match(/experience|অভিজ্ঞতা|year/)) reply = KB.exp;
    else if(t.match(/contact|phone|email/))     reply = KB.contact;
    else if(t.match(/price|cost|টাকা|দাম/))     reply = KB.price;
    else if(t.match(/excel|sheets/i))           reply = '📊 Excel-এ VLOOKUP, Power Query, Dashboard, Automation — ৮ বছরের অভিজ্ঞতা!';
    else if(t.match(/navana|pharma/i))          reply = '🏢 Navana Pharmaceuticals PLC-এ ৮+ বছর কাজ করেছেন।';

    showTyping();
    setTimeout(() => { removeTyping(); addMsg(reply,'bot'); }, 900);
  }

  send.addEventListener('click', () => {
    const v = input.value.trim(); if(!v) return;
    addMsg(v,'user'); input.value='';
    quick.style.display='none';
    botReply(v);
  });
  input.addEventListener('keypress', e => { if(e.key==='Enter') send.click(); });

  /* Quick বাটন */
  document.querySelectorAll('.cbq').forEach(q => q.addEventListener('click', () => {
    addMsg(q.textContent,'user');
    showTyping();
    setTimeout(() => { removeTyping(); addMsg(KB[q.dataset.q]||KB.default,'bot'); }, 800);
    quick.style.display='none';
  }));
})();


/* ══════════════════════════════════════════════════════════
   ১৮. NUMBER TO WORDS TOOL — সংখ্যা থেকে কথায়
══════════════════════════════════════════════════════════ */

/* সংখ্যা থেকে ইংরেজি শব্দে রূপান্তর */
function numberToWords(n) {
  n = Math.floor(n);
  if (n <= 0 || n >= 10000000000)
    return { ok:false, msg:'❌ পরিসীমার বাইরে! ১ থেকে ৯,৯৯৯ কোটির মধ্যে হতে হবে।' };

  const ones = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine',
                 'Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen',
                 'Seventeen','Eighteen','Nineteen'];
  const tens = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];

  /* দুই সংখ্যার কথায় */
  function tw(n) {
    if(n<=0) return '';
    if(n<20) return ones[n]+' ';
    return tens[Math.floor(n/10)]+' '+(ones[n%10]?ones[n%10]+' ':'');
  }

  let r='';
  const crore = Math.floor(n/10000000);     if(crore) r+=tw(crore)+'Crore ';
  const lakh  = Math.floor((n%10000000)/100000);  if(lakh)  r+=tw(lakh)+'Lakh ';
  const thou  = Math.floor((n%100000)/1000);  if(thou)  r+=tw(thou)+'Thousand ';
  const hund  = Math.floor((n%1000)/100);   if(hund)  r+=ones[hund]+' Hundred ';
  const rem   = n%100;                       if(rem)   r+=tw(rem);

  return { ok:true, msg:'Tk. '+r.trim().replace(/\s+/g,' ')+' Taka Only' };
}

/* Convert বাটন */
function n2wDo() {
  const raw = document.getElementById('n2wIn').value;
  const num = parseFloat(raw);
  const out = document.getElementById('n2wOut');
  const res = document.getElementById('n2wRes');
  const dsp = document.getElementById('n2wNum');

  if(!raw||isNaN(num)){
    out.className='tl-res-val err'; out.textContent='❌ বৈধ সংখ্যা লিখুন।';
    dsp.textContent='—'; res.classList.remove('ok'); return;
  }
  dsp.textContent = num.toLocaleString('en-BD');
  const r = numberToWords(num);
  out.className   = r.ok ? 'tl-res-val ok' : 'tl-res-val err';
  out.textContent = r.msg;
  res.classList.toggle('ok', r.ok);
}

/* Quick example */
function n2wSet(n) {
  document.getElementById('n2wIn').value = n; n2wDo();
}

/* Clear */
function n2wReset() {
  document.getElementById('n2wIn').value='';
  document.getElementById('n2wOut').className='tl-res-val ph';
  document.getElementById('n2wOut').textContent='এখানে ফলাফল দেখাবে...';
  document.getElementById('n2wNum').textContent='—';
  document.getElementById('n2wRes').classList.remove('ok');
}

/* Enter key দিয়ে convert */
document.addEventListener('DOMContentLoaded', () => {
  const i = document.getElementById('n2wIn');
  if(i) i.addEventListener('keydown', e => { if(e.key==='Enter') n2wDo(); });
});


/* ══════════════════════════════════════════════════════════
   ১৯. ACHIEVEMENT POPUP — অর্জন notification
   নির্দিষ্ট section-এ পৌঁছালে toast notification দেখাবে
══════════════════════════════════════════════════════════ */
(function initAchievements() {
  const popup = document.getElementById('achPop');
  const ico   = document.getElementById('achIco');
  const ttl   = document.getElementById('achTtl');
  const dsc   = document.getElementById('achDsc');
  if (!popup) return;

  /* section id → achievement */
  const list = [
    { id:'about',    emoji:'👋', title:'Explorer!',       desc:"You discovered Mehidi's story!" },
    { id:'skills',   emoji:'🎯', title:'Skill Scout!',    desc:'You explored the skill set!' },
    { id:'projects', emoji:'🏆', title:'Project Hunter!', desc:'You found real Excel projects!' },
    { id:'tools',    emoji:'🔧', title:'Tool Master!',    desc:'You discovered live Excel tools!' },
    { id:'contact',  emoji:'🚀', title:'Ready to Go!',    desc:"Let's build something amazing!" },
  ];

  const shown = new Set();
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const a = list.find(x => x.id === e.target.id);
      if (!a || shown.has(a.id)) return;
      shown.add(a.id);
      ico.textContent = a.emoji; ttl.textContent = a.title; dsc.textContent = a.desc;
      popup.classList.add('show');
      setTimeout(() => popup.classList.remove('show'), 3500);
    });
  }, { threshold: 0.4 });

  list.forEach(a => { const el=document.getElementById(a.id); if(el) obs.observe(el); });
})();


/* ══════════════════════════════════════════════════════════
   ২০. BACK TO TOP — উপরে যাওয়ার বাটন
══════════════════════════════════════════════════════════ */
document.getElementById('toTop')?.addEventListener('click', () => {
  window.scrollTo({ top:0, behavior:'smooth' });
});


/* ══════════════════════════════════════════════════════════
   ২১. MAGNETIC BUTTONS — বাটনে magnetic hover effect
   মাউস কাছে গেলে বাটন সামান্য টানা অনুভব হয়
══════════════════════════════════════════════════════════ */
document.querySelectorAll('.btn-p, .hire-btn').forEach(btn => {
  btn.addEventListener('mousemove', e => {
    const r  = btn.getBoundingClientRect();
    const dx = e.clientX - (r.left + r.width/2);
    const dy = e.clientY - (r.top  + r.height/2);
    btn.style.transform = `translate(${dx*.15}px,${dy*.15}px) translateY(-3px)`;
  });
  btn.addEventListener('mouseleave', () => { btn.style.transform=''; });
});


/* ══════════════════════════════════════════════════════════
   ২২. SECTION BACKGROUND TRANSITION
   স্ক্রোলে body-র background ধীরে ধীরে পরিবর্তন হয়
══════════════════════════════════════════════════════════ */
(function initBgShift() {
  const map = {
    home:'#050810', about:'#080f28', skills:'#100520',
    projects:'#021408', tools:'#180404',
    availability:'#011208', contact:'#160410'
  };
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting && map[e.target.id]) {
        document.body.style.transition = 'background .8s ease';
        document.body.style.background = map[e.target.id];
      }
    });
  }, { threshold: 0.35, rootMargin:'-10% 0px -10% 0px' });
  document.querySelectorAll('section[id],div[id]').forEach(s => obs.observe(s));
})();


/* ══════════════════════════════════════════════════════════
   কনসোল বার্তা — developer এর জন্য
══════════════════════════════════════════════════════════ */
console.log('%c MHRasel Portfolio ✅ ', 'background:#00f5a0;color:#000;font-weight:bold;padding:4px 10px;border-radius:4px;font-size:14px;');
console.log('%c Built with ❤️ — Mehidi Hasan Rasel ', 'color:#7c3aed;font-size:12px;');
