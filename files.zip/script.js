/* ============================================================
   GLASSMORPHISM CARD STACK — script.js
   ============================================================ */

'use strict';

// ── Data ──────────────────────────────────────────────────

const SKILLS = [
  {
    title:    'HTML & CSS Mastery',
    desc:     'Modern semantic markup, flexbox/grid layouts, custom properties, animations, and responsive design systems that scale beautifully.',
    tags:     ['Flexbox', 'CSS Grid', 'Animations', 'Responsive'],
    progress: 92,
  },
  {
    title:    'JavaScript ES6+',
    desc:     'Async/Await, destructuring, closures, event loops, DOM manipulation, and modern JS patterns for production-ready applications.',
    tags:     ['ES6+', 'Async/Await', 'DOM API', 'Closures'],
    progress: 87,
  },
  {
    title:    'UI / UX Design',
    desc:     'Figma-to-code workflows, design tokens, accessibility standards, Glassmorphism and modern visual design aesthetics.',
    tags:     ['Figma', 'Design Tokens', 'A11y', 'Glass UI'],
    progress: 78,
  },
  {
    title:    'React & Components',
    desc:     'Hooks, Context API, component architecture, state management, and performance optimisation with React 18+.',
    tags:     ['React Hooks', 'Context API', 'State Mgmt', 'Performance'],
    progress: 83,
  },
];

// CSS custom-property values per theme (matches card order 0-3)
const THEMES = [
  {
    bgFrom:   '#071a10', bgMid: '#0a2218', bgTo: '#061510',
    orb1:     '#2ef07a', orb2: '#00c44f', orb3: '#1aff80',
    accent:   '#60f090',
    progFrom: '#2ef07a', progTo: '#00c44f',
  },
  {
    bgFrom:   '#070f25', bgMid: '#0d1a3a', bgTo: '#050d1f',
    orb1:     '#4f9fff', orb2: '#1a6fff', orb3: '#80baff',
    accent:   '#80b8ff',
    progFrom: '#4f9fff', progTo: '#1a6fff',
  },
  {
    bgFrom:   '#041a1a', bgMid: '#082828', bgTo: '#031515',
    orb1:     '#00e8d8', orb2: '#00b8a8', orb3: '#40ffe8',
    accent:   '#00e8d8',
    progFrom: '#00e8d8', progTo: '#00b8a8',
  },
  {
    bgFrom:   '#1a0715', bgMid: '#280d22', bgTo: '#150510',
    orb1:     '#ff80c8', orb2: '#e040a0', orb3: '#ff60b8',
    accent:   '#ff80c8',
    progFrom: '#ff80c8', progTo: '#e040a0',
  },
];

// ── DOM refs ──────────────────────────────────────────────

const wrapper      = document.getElementById('pageWrapper');
const orb1El       = document.getElementById('orb1');
const orb2El       = document.getElementById('orb2');
const orb3El       = document.getElementById('orb3');
const skillIndexEl = document.getElementById('skillIndex');
const skillTitleEl = document.getElementById('skillTitle');
const skillDescEl  = document.getElementById('skillDesc');
const tagListEl    = document.getElementById('tagList');
const progressFill = document.getElementById('progressFill');
const progressVal  = document.getElementById('progressVal');
const infoPanel    = document.querySelector('.info-panel');

// ── State ─────────────────────────────────────────────────

let current     = 0;
let isAnimating = false;

// Scroll accumulator — require intentional scroll distance
let scrollAcc = 0;
const SCROLL_THRESHOLD = 80;

// ── Apply CSS theme vars ───────────────────────────────────

function applyTheme(idx) {
  const t  = THEMES[idx];
  const el = document.documentElement; // :root

  el.style.setProperty('--bg-from',   t.bgFrom);
  el.style.setProperty('--bg-mid',    t.bgMid);
  el.style.setProperty('--bg-to',     t.bgTo);
  el.style.setProperty('--orb1-col',  t.orb1);
  el.style.setProperty('--orb2-col',  t.orb2);
  el.style.setProperty('--orb3-col',  t.orb3);
  el.style.setProperty('--accent',    t.accent);
  el.style.setProperty('--prog-from', t.progFrom);
  el.style.setProperty('--prog-to',   t.progTo);

  // Orb backgrounds are inline so they inherit the variable
  orb1El.style.background = t.orb1;
  orb2El.style.background = t.orb2;
  orb3El.style.background = t.orb3;
}

// ── Position cards in stack ───────────────────────────────

function positionCards(activeIdx) {
  const total = SKILLS.length;

  for (let i = 0; i < total; i++) {
    const card = document.getElementById('card' + i);
    // How many positions behind the active card?
    const offset = (i - activeIdx + total) % total;

    let translateY, scale, opacity, zIndex, shadow;

    switch (offset) {
      case 0:
        translateY = 0;   scale = 1;    opacity = 1;    zIndex = 10;
        shadow = '0 28px 80px rgba(0,0,0,0.55)';
        break;
      case 1:
        translateY = 20;  scale = 0.94; opacity = 0.68; zIndex = 9;
        shadow = 'none';
        break;
      case 2:
        translateY = 38;  scale = 0.88; opacity = 0.36; zIndex = 8;
        shadow = 'none';
        break;
      default:
        translateY = 54;  scale = 0.82; opacity = 0.14; zIndex = 7;
        shadow = 'none';
        break;
    }

    card.style.transform  = `translateY(${translateY}px) scale(${scale})`;
    card.style.opacity    = opacity;
    card.style.zIndex     = zIndex;
    card.style.boxShadow  = shadow;
  }
}

// ── Update info panel text ────────────────────────────────

function updateInfo(idx) {
  const skill = SKILLS[idx];

  // Fade out
  skillTitleEl.style.opacity   = '0';
  skillTitleEl.style.transform = 'translateY(12px)';
  skillDescEl.style.opacity    = '0';
  skillDescEl.style.transform  = 'translateY(12px)';
  tagListEl.style.opacity      = '0';

  setTimeout(() => {
    // Update text content
    skillIndexEl.textContent = `Skill 0${idx + 1} / 0${SKILLS.length}`;
    skillTitleEl.textContent = skill.title;
    skillDescEl.textContent  = skill.desc;
    progressFill.style.width = skill.progress + '%';
    progressVal.textContent  = skill.progress + '%';

    // Rebuild tags
    tagListEl.innerHTML = '';
    skill.tags.forEach((label, i) => {
      const span = document.createElement('span');
      span.className = 'tag' + (i === 0 ? ' is-active' : '');
      span.textContent = label;
      tagListEl.appendChild(span);
    });

    // Apply theme (updates CSS vars + accent color)
    applyTheme(idx);

    // Fade in
    skillTitleEl.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
    skillDescEl.style.transition  = 'opacity 0.7s ease, transform 0.7s ease';
    tagListEl.style.transition    = 'opacity 0.7s ease';

    requestAnimationFrame(() => {
      skillTitleEl.style.opacity   = '1';
      skillTitleEl.style.transform = 'translateY(0)';
      skillDescEl.style.opacity    = '1';
      skillDescEl.style.transform  = 'translateY(0)';
      tagListEl.style.opacity      = '1';
    });
  }, 280);
}

// ── Navigate to a specific card index ────────────────────

function goTo(idx) {
  if (isAnimating)       return;
  if (idx === current)   return;
  if (idx < 0 || idx >= SKILLS.length) return;

  isAnimating = true;
  current = idx;

  positionCards(current);
  updateInfo(current);

  // Card transition is 1.4 s — lock input for that duration + buffer
  setTimeout(() => { isAnimating = false; }, 1500);
}

// ── Scroll handler ────────────────────────────────────────

let scrollTimer = null;

function handleWheel(e) {
  // If currently animating, swallow the event and do nothing
  if (isAnimating) {
    e.preventDefault();
    return;
  }

  scrollAcc += e.deltaY;

  clearTimeout(scrollTimer);

  // Haven't scrolled enough yet — accumulate
  if (Math.abs(scrollAcc) < SCROLL_THRESHOLD) {
    e.preventDefault();
    // Reset accumulator if user stops scrolling
    scrollTimer = setTimeout(() => { scrollAcc = 0; }, 500);
    return;
  }

  const direction = scrollAcc > 0 ? 1 : -1;
  scrollAcc = 0;
  clearTimeout(scrollTimer);

  const next = current + direction;

  // Within range: navigate to next card
  if (next >= 0 && next < SKILLS.length) {
    e.preventDefault();
    goTo(next);
    return;
  }

  // Out of range: let the page scroll naturally
  // (do NOT call e.preventDefault() here)
}

// ── Touch support ─────────────────────────────────────────

let touchStartY = 0;

function handleTouchStart(e) {
  touchStartY = e.touches[0].clientY;
}

function handleTouchEnd(e) {
  if (isAnimating) return;
  const dy  = touchStartY - e.changedTouches[0].clientY;
  if (Math.abs(dy) < 40) return;

  const direction = dy > 0 ? 1 : -1;
  const next      = current + direction;
  goTo(next);
}

// ── Event listeners ───────────────────────────────────────

wrapper.addEventListener('wheel',      handleWheel,      { passive: false });
wrapper.addEventListener('touchstart', handleTouchStart, { passive: true  });
wrapper.addEventListener('touchend',   handleTouchEnd,   { passive: true  });

// ── Boot ──────────────────────────────────────────────────

positionCards(0);
updateInfo(0);
applyTheme(0);
