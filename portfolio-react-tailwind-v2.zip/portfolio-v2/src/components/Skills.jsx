import { useEffect, useRef, useState } from 'react'

const SKILLS = [
  { name: 'HTML', pct: 95 },
  { name: 'CSS', pct: 90 },
  { name: 'JavaScript', pct: 85 },
  { name: 'React JS', pct: 83 },
  { name: 'Node JS', pct: 72 },
  { name: 'UI/UX Design', pct: 78 },
]

function SkillBar({ name, pct }) {
  const [width, setWidth] = useState(0)
  const ref = useRef(null)

  useEffect(() => {
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) { setWidth(pct); obs.disconnect() }
    }, { threshold: 0.3 })
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [pct])

  return (
    <div className="skill-item" ref={ref}>
      <div className="skill-label">
        <span>{name}</span>
        <span>{pct}%</span>
      </div>
      <div className="skill-bar-bg">
        <div className="skill-bar-fill" style={{ width: `${width}%` }} />
      </div>
    </div>
  )
}

export default function Skills() {
  return (
    <section className="skills-section" id="skills">
      <h2 className="heading reveal">
        My <span>Skills</span>
      </h2>
      <div className="skills-container">
        {SKILLS.map(s => (
          <SkillBar key={s.name} name={s.name} pct={s.pct} />
        ))}
      </div>
    </section>
  )
}
