export default function About() {
  return (
    <section className="about-section" id="about">
      {/* Image */}
      <div className="about-img reveal">
        <img
          src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face"
          alt="About John"
        />
      </div>

      {/* Text */}
      <div className="about-content reveal">
        <h2 className="text-4xl font-bold mb-2">
          About <span style={{ color: '#00eeff' }}>Me</span>
        </h2>
        <h3>Frontend Developer!</h3>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex delectus iste,
          aliquid officia quasi aliquam deleniti consequuntur suscipit ducimus tenetur
          maiores vel commodi veniam ratione! Nisi praesentium delectus fugiat officiis
          cupiditate in illum, modi unde recusandae, molestiae excepturi voluptatum temporibus.
        </p>
        <p>
          Passionate about building pixel-perfect, high-performance web experiences that
          combine elegant design with robust code. I specialize in React and modern CSS
          to deliver stunning user interfaces.
        </p>
        <a href="#" className="btn">Read More</a>
      </div>
    </section>
  )
}
