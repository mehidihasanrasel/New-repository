# 🚀 Portfolio Website — React + Tailwind CSS

YouTube video এর design এর মতো করে তৈরি।  
Stack: **React 18 + Tailwind CSS v3 + Vite + Font Awesome**

---

## ▶️ Run করার নিয়ম

### Step 1 — Node.js install করুন
https://nodejs.org থেকে Node.js v18+ ডাউনলোড করুন।

### Step 2
```bash
cd portfolio
npm install
npm run dev
```
Browser এ যান → **http://localhost:5173**

---

## 📸 নিজের ছবি যোগ করবেন যেভাবে

1. আপনার ছবি `src/assets/` ফোল্ডারে রাখুন (যেমন: `hero.jpg`)
2. `src/components/Home.jsx` খুলুন
3. ফাইলের উপরে add করুন:
   ```js
   import heroImg from '../assets/hero.jpg'
   ```
4. `<img src="https://..." />` এর বদলে লিখুন:
   ```jsx
   <img src={heroImg} alt="John Kendric" />
   ```
5. একইভাবে `About.jsx` এও করুন।

---

## 📁 Project Structure

```
portfolio/
├── src/
│   ├── components/
│   │   ├── Navbar.jsx      ← Sticky + Mobile menu
│   │   ├── Home.jsx        ← Hero + Typing animation
│   │   ├── About.jsx       ← About section
│   │   ├── Skills.jsx      ← Animated skill bars
│   │   ├── Services.jsx    ← Service cards
│   │   ├── Portfolio.jsx   ← Project grid + hover overlay
│   │   ├── Contact.jsx     ← Contact form + info
│   │   └── Footer.jsx
│   ├── hooks/
│   │   └── useTyped.js     ← Custom typing hook
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css           ← Tailwind + custom styles
├── tailwind.config.js
├── vite.config.js
└── package.json
```

## ✨ Features
- ✅ Typing animation (Hero)
- ✅ Animated circular photo with spinning border
- ✅ Scroll reveal animation (সব section)
- ✅ Animated skill bars
- ✅ Service cards (hover glow)
- ✅ Portfolio grid (hover overlay)
- ✅ Contact form
- ✅ Sticky navbar
- ✅ Mobile responsive + hamburger menu
- ✅ Back-to-top button
