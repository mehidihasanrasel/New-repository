import useTyped from '../hooks/useTyped'

const WORDS = ['Frontend Developer', 'Web Designer', 'UI/UX Designer', 'React Developer']

export default function Home() {
  const typed = useTyped(WORDS)

  return (
    <section className="home-section" id="home">
      {/* Left */}
      <div className="home-content">
        <h3>Hello, It's Me</h3>
        <h1>John Kendric</h1>
        <h3>
          And I'm a <span className="typed-text">{typed}</span>
          <span className="cursor" />
        </h3>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium, ab autem
          repellat reiciendis ipsam perspiciatis. Quisquam earum debitis optio!
        </p>

        {/* Social icons */}
        <div className="social-media">
          <a href="#" aria-label="Facebook"><i className="fab fa-facebook-f" /></a>
          <a href="#" aria-label="Twitter"><i className="fab fa-twitter" /></a>
          <a href="#" aria-label="Instagram"><i className="fab fa-instagram" /></a>
          <a href="#" aria-label="LinkedIn"><i className="fab fa-linkedin-in" /></a>
        </div>

        <a href="#" className="btn">Download CV</a>
      </div>

      {/* Right – Photo */}
      <div className="home-img">
        <div className="img-box">
          {/*
            নিজের ছবি add করতে:
            1. আপনার ছবি src/assets/hero.jpg এ রাখুন
            2. নিচের src পরিবর্তন করুন: import heroImg from '../assets/hero.jpg'
            এবং <img src={heroImg} ... />
          */}
          <img
            src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face"
            alt="John Kendric"
          />
        </div>
      </div>
    </section>
  )
}
