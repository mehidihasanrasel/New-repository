export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-text">
        <p>Copyright &copy; 2025 by <span style={{ color: '#00eeff' }}>John Kendric</span> | All Rights Reserved.</p>
      </div>
      <div className="footer-iconTop">
        <a href="#home" aria-label="Back to top">
          <i className="fas fa-angle-up" />
        </a>
      </div>
    </footer>
  )
}
