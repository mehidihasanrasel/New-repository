const PROJECTS = [
  {
    img: 'https://images.unsplash.com/photo-1547658719-da2b51169166?w=600&q=80',
    title: 'Web Design',
    desc: 'A fully responsive web design project.',
  },
  {
    img: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600&q=80',
    title: 'Dev Setup',
    desc: 'Custom developer workspace setup.',
  },
  {
    img: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600&q=80',
    title: 'Dark Studio',
    desc: 'Modern dark-themed studio website.',
  },
  {
    img: 'https://images.unsplash.com/photo-1593720213428-28a5b9e94613?w=600&q=80',
    title: 'Web Application',
    desc: 'Full-stack web application.',
  },
  {
    img: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=600&q=80',
    title: 'Keyboard Lab',
    desc: 'E-commerce product page design.',
  },
  {
    img: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&q=80',
    title: 'Code Night',
    desc: 'Late-night coding productivity app.',
  },
]

export default function Portfolio() {
  return (
    <section className="portfolio-section" id="portfolio">
      <h2 className="heading reveal">
        Latest <span>Project</span>
      </h2>
      <div className="portfolio-container">
        {PROJECTS.map((p, i) => (
          <div className="portfolio-box reveal" key={i} style={{ transitionDelay: `${i * 0.1}s` }}>
            <img src={p.img} alt={p.title} loading="lazy" />
            <div className="portfolio-layer">
              <h4>{p.title}</h4>
              <p>{p.desc}</p>
              <a href="#" aria-label="View project">
                <i className="fas fa-external-link-alt" />
              </a>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
