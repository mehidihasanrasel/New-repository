import { useState } from 'react'

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', mobile: '', subject: '', message: '' })
  const [sent, setSent] = useState(false)

  const handle = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const submit = e => {
    e.preventDefault()
    setSent(true)
    setForm({ name: '', email: '', mobile: '', subject: '', message: '' })
    setTimeout(() => setSent(false), 3000)
  }

  return (
    <section className="contact-section" id="contact">
      <h2 className="heading reveal">Contact <span>Me!</span></h2>

      <div className="contact-container">
        {/* Form */}
        <form className="contact-form reveal" onSubmit={submit}>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-0">
            <input
              style={{ marginRight: '0', borderRadius: '12px 12px 0 0' }}
              className="contact-form input"
              type="text" name="name" placeholder="Full Name"
              value={form.name} onChange={handle} required
            />
            <input
              style={{ borderRadius: '12px 12px 0 0' }}
              type="email" name="email" placeholder="Email Address"
              value={form.email} onChange={handle} required
            />
            <input
              type="tel" name="mobile" placeholder="Mobile Number"
              value={form.mobile} onChange={handle}
            />
            <input
              type="text" name="subject" placeholder="Email Subject"
              value={form.subject} onChange={handle}
            />
          </div>
          <textarea
            name="message" rows={7} placeholder="Your Message"
            value={form.message} onChange={handle} required
          />
          {sent
            ? <p style={{ color: '#00eeff', fontWeight: 600 }}>✓ Message sent successfully!</p>
            : <button type="submit" className="btn" style={{ marginTop: 0 }}>Send Message</button>
          }
        </form>

        {/* Info */}
        <div className="contact-info reveal">
          <h3>Get In Touch</h3>
          <p>
            I'm open to freelance projects, collaborations, and exciting opportunities.
            Feel free to reach out anytime!
          </p>
          <div className="info-box">
            <i className="fas fa-envelope" />
            <p>johnkendric@email.com</p>
          </div>
          <div className="info-box">
            <i className="fas fa-phone" />
            <p>+880 1700-000000</p>
          </div>
          <div className="info-box">
            <i className="fas fa-map-marker-alt" />
            <p>Dhaka, Bangladesh</p>
          </div>
          <div className="social-media mt-6">
            <a href="#" aria-label="Facebook"><i className="fab fa-facebook-f" /></a>
            <a href="#" aria-label="Twitter"><i className="fab fa-twitter" /></a>
            <a href="#" aria-label="Instagram"><i className="fab fa-instagram" /></a>
            <a href="#" aria-label="LinkedIn"><i className="fab fa-linkedin-in" /></a>
          </div>
        </div>
      </div>
    </section>
  )
}
