const SERVICES = [
  {
    icon: 'fa-solid fa-code',
    title: 'Web Development',
    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam quia voluptas nostrum? Dolore culpa eos possimus fugit reprehenderit aperiam eveniet.',
  },
  {
    icon: 'fa-solid fa-palette',
    title: 'Graphic Design',
    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam quia voluptas nostrum? Dolore culpa eos possimus fugit reprehenderit aperiam eveniet.',
  },
  {
    icon: 'fa-solid fa-chart-line',
    title: 'Digital Marketing',
    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam quia voluptas nostrum? Dolore culpa eos possimus fugit reprehenderit aperiam eveniet.',
  },
]

export default function Services() {
  return (
    <section className="services-section" id="services">
      <h2 className="heading reveal">
        Our <span>Services</span>
      </h2>
      <div className="services-container">
        {SERVICES.map((s, i) => (
          <div className="service-box reveal" key={i} style={{ transitionDelay: `${i * 0.15}s` }}>
            <i className={s.icon} />
            <h3>{s.title}</h3>
            <p>{s.desc}</p>
            <a href="#">Read More</a>
          </div>
        ))}
      </div>
    </section>
  )
}
