import { useState, useEffect } from 'react'

const links = ['Home', 'About', 'Skills', 'Services', 'Portfolio', 'Contact']

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [active, setActive] = useState('Home')
  const [sticky, setSticky] = useState(false)

  useEffect(() => {
    const fn = () => setSticky(window.scrollY > 100)
    window.addEventListener('scroll', fn)
    return () => window.removeEventListener('scroll', fn)
  }, [])

  const scrollTo = (id) => {
    document.getElementById(id.toLowerCase())?.scrollIntoView({ behavior: 'smooth' })
    setActive(id)
    setMenuOpen(false)
  }

  return (
    <header className={`header${sticky ? ' sticky shadow-lg' : ''}`}>
      {/* Logo */}
      <a href="#home" className="logo" onClick={() => scrollTo('Home')}>
        John<span>.</span>
      </a>

      {/* Nav links */}
      <nav className={`navbar${menuOpen ? ' open' : ''}`}>
        {links.map(l => (
          <a
            key={l}
            href={`#${l.toLowerCase()}`}
            className={active === l ? 'active' : ''}
            onClick={e => { e.preventDefault(); scrollTo(l) }}
          >
            {l}
          </a>
        ))}
      </nav>

      {/* Hamburger */}
      <div className="menu-icon" onClick={() => setMenuOpen(o => !o)}>
        <i className={`fas ${menuOpen ? 'fa-times' : 'fa-bars'}`} />
      </div>
    </header>
  )
}
